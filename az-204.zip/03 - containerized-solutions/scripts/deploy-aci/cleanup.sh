#!/bin/bash

az group delete --name robazresourcegroup --no-wait --yes