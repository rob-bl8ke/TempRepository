#!/bin/bash

az group delete --name robaz-acr-resourcegroup --no-wait --yes
rm Dockerfile