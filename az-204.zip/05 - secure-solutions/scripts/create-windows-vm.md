
Download 
How to fix your current security settings do not allow this file to be downloaded?
Solution 1:
Open Internet Explorer.
Click Tools in top right corner and then Internet Options.
Click on the Security tab.
Select the Internet Zone.
Click on the Custom Level button and then scroll down to Downloads.
Make sure to enable File download.
Click Apply and OK.
Restart Internet Explorer and check if that helps.