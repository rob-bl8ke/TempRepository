[Route custom events to web endpoint by using Azure CLI](https://learn.microsoft.com/en-us/training/modules/azure-event-grid/8-event-grid-custom-events)

