// From an incoming queue message that is a JSON object, 
// add fields and write to Table Storage
module.exports = async function (context, order) {
    order.PartitionKey = "Orders";
    order.RowKey = generateRandomId(); 

    context.bindings.order = order;
};

function generateRandomId() {
    return Math.random().toString(36).substring(2, 15) +
        Math.random().toString(36).substring(2, 15);
}


module.exports = async function (context, order) {
    order.PartitionKey = "Orders";
    order.RowKey = generateRandomId();
    
    context.bindings.order = order;
}

module.exports = async function(context, order) {
    order.PartitionKey = "Orders";
    order.RowKey = generateRandomId();
}