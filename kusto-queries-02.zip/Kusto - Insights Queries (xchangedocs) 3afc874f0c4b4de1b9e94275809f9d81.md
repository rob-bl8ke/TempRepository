# Kusto - Insights Queries (xchangedocs)

Category: Kusto
Created: July 8, 2022 12:08 PM
Status: Open
Updated: September 13, 2022 4:44 PM

# Kusto - Insights Queries (xchangedocs)

Tags: DevOps, Support

[Kusto Query Language (KQL) Tutorial](https://www.youtube.com/playlist?list=PLWf6TEjiiuIDDXxYJQryn0KxZ5OjdG83n)

Log Stream (Go to Log Stream and run xHR requests via Google Chrome.

- You can replay your xhr requests

In insights you can go to Failures. Failures will give you all the 500s and you get to look at some cool graphs and break down into the actual failure exception messages.

# Errors (Bad Requests)

---

```
let userId = "d6946238-e72c-4d87-fb38-08d7fcb8a9a0";

let fromDate = startofday(datetime("2021-02-25 10:48:35.000 PM"));
let toDate = endofday(datetime("2021-02-25 10:58:35.000 PM"));

// Last time tried was Thursday 10:42 PM...
// let fromDate = ago(5d);
// let toDate = now() + 1d;

let minResponseCode = 400;
let maxResponseCode = 499;

requests
| join (dependencies) on operation_Id
| where timestamp > fromDate and timestamp < toDate
| where customDimensions1.Error != ""
| where customDimensions.["xd-user-id"] == userId
| where toint(resultCode) >= minResponseCode and toint(resultCode) < maxResponseCode
| order by timestamp desc

```

# Exception Information

---

```
// let userId = "E119606D-6C1E-47D2-9689-08D92EE266EC";

// let fromDate = ago(10d);
// let toDate = now() + 1d;
// let fromDate = startofday(datetime("2021-01-01"));
// let toDate = endofday(datetime("2021-01-21"));

// Get all server errors for user by endpoint
requests
| join (
    exceptions
) on operation_Id
// | where timestamp > fromDate and timestamp < toDate
// | where customDimensions.["xd-user-id"] == userId
| where success == false
| project timestamp, details
| order by timestamp desc

```

## User Login Information

```
let userId = "E119606D-6C1E-47D2-9689-08D92EE266EC";

let fromDate = startofday(datetime("2021-01-01"));
// let toDate = endofday(datetime("2021-01-21"));
// let fromDate = ago(10d);
let toDate = now() + 1d;

requests
| where timestamp > fromDate and timestamp < toDate
| where operation_Name contains "GetAuthenticatedUser"
| order by timestamp desc
```

Other possible ways to find out User Login Information:

- The application insights - insights-xdprod4can | Logs | traces, which is tedious
- The Azure B2C access logs

```
let fromDate = ago(60d);
let toDate = now() + 1d;
requests
| where name == 'GET Documents/DownloadFromToken [downloadToken]' and resultCode == 400
| where timestamp > fromDate and timestamp < toDate
| summarize count() by bin(timestamp, 1d)

```

# View by Result Code

```
let userId = "E119606D-6C1E-47D2-9689-08D92EE266EC";

let fromDate = ago(10d);
let toDate = now() + 1d;
// let fromDate = startofday(datetime("2021-01-01"))
// let toDate = endofday(datetime("2021-01-21"))

let minResponseCode = 200;
let maxResponseCode = 600;

requests
| extend response = case(
        resultCode == 200, "200 - OK",
        resultCode == 201, "201 - Created",
        resultCode == 202, "202 - Accepted",
        resultCode == 203, "203 - Non-Authoritative Information",
        resultCode == 204, "204 - No Content",
        resultCode == 205, "205 - Reset Content",
        resultCode == 206, "206 - Partial Content",
        resultCode == 301, "301 - Moved permanently",
        resultCode == 302, "302 - Found",
        resultCode == 303, "303 - See Other",
        resultCode == 304, "304 - Not Modified",
        resultCode == 305, "305 - Use Proxy",
        resultCode == 306, "306 - (Unused)",
        resultCode == 307, "307 - Temporary Redirect",
        resultCode == 400, "400 - Bad Request",
        resultCode == 401, "401 - Unauthorized",
        resultCode == 403, "403 - Forbidden",
        resultCode == 404, "404 - Resource not found",
        resultCode == 405, "405 - Method Not Allowed",
        resultCode == 406, "406 - Not Acceptable",
        resultCode == 407, "407 - Proxy Authentication Required",
        resultCode == 408, "408 - Request Timeout",
        resultCode == 409, "409 - Conflict",
        resultCode == 410, "410 - Gone",
        resultCode == 411, "411 - Length Required",
        resultCode == 412, "412 - Precondition Failed",
        resultCode == 413, "413 - Request Entity Too Large",
        resultCode == 414, "414 - Request URI Too Long",
        resultCode == 415, "415 - Unsupported Media Type",
        resultCode == 416, "416 - Requested Range not satisfiable",
        resultCode == 417, "417 - Expectation Failed",
        resultCode == 500, "500 - Internal Server Error",
        resultCode == 501, "501 - Not Implemented",
        resultCode == 502, "502 - Bad Gateway",
        resultCode == 503, "503 - Service Unavailable",
        resultCode == 504, "504 - Gateway Timeout",
        resultCode == 505, "505 - HTTP Version Not Supported",
        "--UNKNOWN--"
    )
| where timestamp > fromDate and timestamp < toDate
| where customDimensions.["xd-user-id"] == userId
| where toint(resultCode) >= minResponseCode and toint(resultCode) < maxResponseCode
| project timestamp, customDimensions.["xd-user-id"], operation_Id, operation_Name, response, duration
| order by timestamp desc

```