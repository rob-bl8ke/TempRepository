# ExamPro - Azure Monitoring

Created: November 29, 2023 5:26 AM
Status: Open
Updated: November 29, 2023 6:18 AM

# Azure Monitor

---

## Introduction to Azure Monitor

Azure Monitor comprehensive solution **for collecting, analyzing, and acting on telemetry** from your cloud and on-premises environments

- Create Visual Dashboards
- Smart Alerts
- Automated Actions
- Log Monitoring

Many Azure services by default are already sending telemetry data to Azure Monitor

### Reference

[Overview of Log Analytics in Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/log-query/log-analytics-overview)

## The Pillars of Obervability

**What is Observability?**

The ability to measure and understand how internal systems work in order to answer questions regarding performance, tolerance, security and faults with a system/application.

To obtain observability you need to use **Metrics, Logs and Traces.**

You have to use them together, using them in isolate does not gain you observability

**Metrics**

A number that is measured over a period of time

eg. If we measured the CPU usage and aggerated it over a period of time we could have an **Average CPU metric**

**Logs**

A text file where each line contains event data about what happened at a certain time.

**Traces**

A history of requests that travels through multiple Apps/services so we can pinpoint performance or failure.

**Looks like they should have called it the Triforce of Observability**

### Reference

[Chapter 4. The Three Pillars of Observability](https://www.oreilly.com/library/view/distributed-systems-observability/9781492033431/ch04.html)

[THREE PILLARS OF OBSERVABILITY: DO YOU HAVE ALL OF THEM?](https://www.scalyr.com/blog/three-pillars-of-observability/#:%7E:text=Logs%2C%20metrics%2C%20and%20traces%20are,hard%20time%20finding%20the%20problem)

## Anatomy of Azure Monitor

The **sources of common monitoring data** to populate datastores Order by (Highest to Lowest)

**Application**

**Operating System**

**Azure Resources**

**Azure Subscription**

**Azure Tenant**

**Custom Sources**

The **functions** that Azure monitor can perform

The two fundamental data stores are Metrics and Logs

### Reference

[Overview of Log Analytics in Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/log-query/log-analytics-overview)

[Sources of monitoring data for Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/agents/data-sources)

## Azure Monitor - Sources

**Application Code:** performance and functionality of application and code.

Performance traces, application logs, and user telemetry.

You need to install **Instrumentation Package** to collect data for Application Insights.

**Availability Tests** responsiveness of your application from different locations on the public Internet.

**Metrics** describing the **performance** and **operation** and custom metrics for your application.

**Logs** store operational data about your application including page views, application requests, exceptions, and traces.

- Send application data to **Azure Storage** for archiving.
- Details of **availability test** stored.
- Debug snapshot data that is captured for a subset of exceptions is stored in Azure Storage.

### Reference

[Overview of Log Analytics in Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/log-query/log-analytics-overview)

[Sources of monitoring data for Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/agents/data-sources)

## Azure Monitor - Sources

- **Log Analytics Agent** is installed for comprehensive monitoring
- **Dependency Agent** collects discovered data about processes running on the virtual machine and external process dependencies
- Agents can be installed on the OS for VMs running in Azure, On-premise or another cloud provider

**Diagnostics Extension** collect performance counters store in **Metrics**

**Application Insights Logs** collect logs and performance counters from the compute resource supporting your application to be analyzed with other application data

- **Azure diagnostics extension** always writes to an **Azure Storage** account.
- Azure Monitor for VMs uses the Log Analytics agent to store heath state information in a custom location.

Diagnostics Extension to stream the data to other locations using **Event Hubs**

### Reference

[Overview of Log Analytics in Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/log-query/log-analytics-overview)

[Sources of monitoring data for Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/agents/data-sources)

[Azure resources](https://docs.microsoft.com/en-us/azure/azure-monitor/agents/data-sources#azure-resources)

## Azure Monitor - Sources

**Resource Logs**

- Resource logs provide insights into the internal operation of an Azure resource.
- Resource logs are created automatically
- You must create a diagnostic setting to specify a destination for them to collected for each resource

**Platform metrics** will write to the **Azure Monitor metrics database** with no configuration.

Access platform metrics from **Metrics Explorer.**

Trending and other analysis using **Log Analytics**

Copy platform metrics to **Logs**

Send resource logs to **Azure Storage** for archiving.

Stream metrics to other locations using **Event Hubs**

### Reference

[Overview of Log Analytics in Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/log-query/log-analytics-overview)

[Sources of monitoring data for Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/agents/data-sources)

[Azure resources](https://docs.microsoft.com/en-us/azure/azure-monitor/agents/data-sources#azure-resources)

## Azure Monitor - Sources

**Azure subscription:** Telemetry related to the health and operation of your Azure subscription

**Azure Service Health** provides information about the health of the Azure services in your subscription that your application and resources rely on.

### Reference

[Azure resources](https://docs.microsoft.com/en-us/azure/azure-monitor/agents/data-sources#azure-resources)

[Overview of Log Analytics in Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/log-query/log-analytics-overview)

[Sources of monitoring data for Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/agents/data-sources)

## Azure Monitor - Sources

Telemetry related to your Azure tenant is collected from **tenant-wide services** such as **Azure Active Directory.**

**Azure Active Directory** reporting contains the history of sign-in activity and audit trail of changes made within a particular tenant.

### Reference

[Azure resources](https://docs.microsoft.com/en-us/azure/azure-monitor/agents/data-sources#azure-resources)

[Overview of Log Analytics in Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/log-query/log-analytics-overview)

[Sources of monitoring data for Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/agents/data-sources)

## Sources Custom Sources

You may need to monitor other resources that have telemetry that can't be collected with the other data sources.

For these resources, write this data to either Metrics or Logs using an **Azure Monitor API.**

Collect log data from any REST client and store in Log Analytics and Azure Monitor metrics database

### Reference

[Azure resources](https://docs.microsoft.com/en-us/azure/azure-monitor/agents/data-sources#azure-resources)

[Overview of Log Analytics in Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/log-query/log-analytics-overview)

[Sources of monitoring data for Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/agents/data-sources)

## Azure Monitor - Data Stores

Azure Monitor collects **two fundamental** types of data from sources: **Logs** and **Metrics**

**Azure Monitor Logs**

- collects and organizes log and performance data from monitored resources
- data logs are consolidated from different sources into **workspaces**
    - platform logs from Azure services,
    - log and performance data from virtual machines agents,
    - usage and performance data from applications can be consolidated
    - In a workspace so they can be analyzed together using a sophisticated query language capable of analyzing millions of records.
- Work with log queries and their results interactively using **Log Analytics**

**Azure Monitor Metrics**

- collects numeric data from monitored resources into a **time series database.**
- Metrics are numerical values collected at regular intervals and describe some aspect of a system at a particular time
- lightweight and capable of supporting near real-time scenarios, useful for alerting and fast detection of issues
- You can analyze them interactively with **Metrics Explorer**

### Reference

[Azure Monitor Metrics overview](https://docs.microsoft.com/en-us/azure/azure-monitor/platform/data-platform-metrics)

## Log Analytics Workspaces

**Log Analytics** **workspace** is a unique environment for Azure Monitor log data

Each **workspace** has its own data repository and configuration, and data sources and solutions are configured to store their data in a particular **workspace**

### Reference

[https://docs.microsoft.com/en-us/azure/azure-monitor/logs/quick-create-workspace](https://app.exampro.co/student/material/az-204/Create%20a%20Log%20Analytics%20workspace%20in%20the%20Azure%20portal)

## Log Analytics

**Log Analytics** is a tool in the Azure portal used **to edit and run log queries** with data in **Azure Monitor Logs.**

Log Analytics uses a query language called KQL

### Reference

[Overview of Log Analytics in Azure Monitor](https://docs.microsoft.com/en-us/azure/azure-monitor/logs/log-analytics-overview)

# Kusto

---

## Kusto and Kusto Query Language (KQL)

**Azure Monitor Logs** is based on Azure Data Explorer, and log queries are written using the same **Kusto query language (KQL)**

KQL can be used in:

- Log Analytics
- Log alert rules
- Workbooks
- Azure Dashboards
- Logic Apps
- PowerShell
- Azure Monitor Logs API

Kusto is based on relational database management systems and supports entities such as **databases, tables, and columns.**

Some query operators include

- calculated columns
- searching and filtering on rows
- group by-aggregates
- join functions

Kusto queries execute in the context of some **Kusto database** that is attached to a **Kusto cluster.**

### Reference

[Kusto 101 - A Jumpstart Guide to KQL](https://squaredup.com/blog/kusto-101-a-jumpstart-guide-to-kql/)

```
StormEvents
| where EventType == 'Flood' and State == 'WASHINGTON'
| sort by DamageProperty desc
| take 5
| project StartTime, EndTime, State, EventType, DamageProperty, EpisodeNarrative
```

## Kusto Entities

Kusto is generally composed of the following entities: **Clusters, Databases, Tables, Columns, Functions**

**Clusters** are entities that hold databases

**Databases** are named entities that hold tables and stored functions

**Tables** are named entities that hold data. A table has an ordered set of columns, and zero or more rows of data, each row holding one data value for each of the columns of the table

**Columns** are named entities that have a scalar data type. Columns are referenced in the query relative to the tabular data stream that is in the context of the specific operator referencing them.

**Stored functions** are named entities that allow the reuse of Kusto queries or query parts.

**External tables** are entities that reference data stored outside the Kusto database.

External tables are used for exporting data from Kusto to external storage as well as for querying external data without ingesting it into Kusto.

### Reference

[Kusto 101 - A Jumpstart Guide to KQL](https://squaredup.com/blog/kusto-101-a-jumpstart-guide-to-kql/)

## Kusto Scalar Data Types

**What are Scalars?**

Scalars are quantities that are fully described by a magnitude (or numerical value) alone

**What are Data Types?**

A data type defines how a piece of data is interpreted

eg. An Integer number could be a datatype

In Kusto, data types are used for various things: - columns can have defined data type, - Function parameters expect specific data types and there are

- **bool, Boolean** represents a **true or false** value
- **datetime, date** represents a date and/or time eg. **2015-12-31 23:59:59.9** Time is always stored in UTC timezone
- **decimal** represents a 128-bit wide, decimal number eg. **12.88**
- **Int** represents a signed, 32-bit wide, integer eg. **5**
- **long** represents a signed, 64-bit wide, integer
- **guid, uuid, uniqueid** represents a 128-bit globally-unique value eg. **74be27de-1e4e-49d9-b579-fe0b331d3642**
- **real** represents a 64-bit wide, double-precision, floating-point number
- **string** represents a Unicode string. Kusto strings are encoded in UTF-8 and by default are limited to 1MB eg. **“hello world”**
- **Timespan** represents a time interval eg. **2d = 2 days, 30m = 30 minutes, 1tick = 100 nano seconds**
- **Dynamic** A special datatype that can be:
    - Accept primitive scalar data type eg. **bool, datetime, guid, int, long, real, string, timespan**
    - Be an array of data types eg. **[1,2,3,”hello”]**
    - Be a property bag of data types **{"a":1, "b":{"a":2}}**
- **Null** is special value that represents a missing value. Any Datatype can hold a value of null

### Reference

[Scalar data types](https://docs.microsoft.com/en-us/azure/data-explorer/kusto/query/scalar-data-types)

[Kusto 101 - A Jumpstart Guide to KQL](https://squaredup.com/blog/kusto-101-a-jumpstart-guide-to-kql/)

## Kusto Control Commands

**Control commands** can modify data and metadata and has its own syntax different from KQL.

The following control command creates a new Kusto table with two columns

A very common control command is **“.show”** for example, this will count all tables

### Reference

[Management (control commands) overview](https://docs.microsoft.com/en-us/azure/data-explorer/kusto/management)

[Getting started with Kusto](https://docs.microsoft.com/en-us/azure/data-explorer/kusto/concepts)

[Kusto 101 - A Jumpstart Guide to KQL](https://squaredup.com/blog/kusto-101-a-jumpstart-guide-to-kql/)

## Kusto Functions

**Functions** are reusable queries or query parts. Kusto supports several kinds of functions:

**Stored functions**, which are **user-defined functions** that are stored and managed by one kind of database's schema entities.

User-defined function belongs to one of two categories:

- Scalar functions (input scalar datatypes, and outputs scalar datatypes)
- Tabular functions (in tabular data, and outputs tabular data)

**Query-defined functions**, which are **user-defined functions** that are defined and used **within the scope of a single query.**

**Built-in functions**, which are hard-coded (defined by Kusto and cannot be modified by users)

- **Special functions** selects Kusto entities eg. **cluster()**
- **Aggregation functions** performs a calculation on a set of values, and returns a single value eg. **count()**
- **Windows functions** operate on multiple rows (records) in a row set at a time. eg. **row_number()**

### Reference

[Management (control commands) overview](https://docs.microsoft.com/en-us/azure/data-explorer/kusto/management)

[Getting started with Kusto](https://docs.microsoft.com/en-us/azure/data-explorer/kusto/concepts)

[Kusto 101 - A Jumpstart Guide to KQL](https://squaredup.com/blog/kusto-101-a-jumpstart-guide-to-kql/)

## Kusto Scalar Operators

These perform comparisons against Scalar Datatypes

**Bitwise (binary) operators**

- binary_and
- binary_not
- binary_or
- binary_shift_left
- binary_shift_right
- binary_xor

**Logical (binary) operators**

- Equality **=**
- Inequality **!=**
- Logical and **and**
- Logical or **or**

**Datetime /timespan arithmetic**

- add or subtract datetime eg. **datetime(1997-06-25) - datetime(1910-06-11)**
- add, subtract, divide or multiple timespan eg. **1d + 2d**

**Numerical operators** (works on int, long and real)

- Add **+**, Subtract ****, Multiply *, Divide /
- Modulo **%**
- Less **<**, Greater **>**, Equal **==**, Not Equal **=!**, Less or Equal **<=**, Greater or Equal **>=**
- Equals to one of the elements **in**
- Not equals to any of the elements **!in**

**String operators**

- == , != , =~, !~, has, has, hasprefixhasprefix, hassuffix , contains, startswith, endswith, matches, in, has_any (many more…)

**between operator** Matches the input that is inside the inclusive range.

- Table1 | where Num1 between (1 .. 10)
- Table1 | where Time between (datetime(2017-01-01) .. datetime(2017-01-01))

### Reference

[Management (control commands) overview](https://docs.microsoft.com/en-us/azure/data-explorer/kusto/management)

[Getting started with Kusto](https://docs.microsoft.com/en-us/azure/data-explorer/kusto/concepts)

[Kusto 101 - A Jumpstart Guide to KQL](https://squaredup.com/blog/kusto-101-a-jumpstart-guide-to-kql/)

## Kusto Tabular Operators

**This is where all the power is !!!**

These perform comparisons against a bunch of rows. There are a lot of tabular operators

**count** — Returns the count of rows in the table.

**take** — returns up to the specified number of rows of data

**sort** — Sort the rows of the input table into order by one or more columns.

**project** — returns a specific set of columns.

**where** — Filters a table to the subset of rows that satisfy a predicate.

**top** — returns the first N records sorted by the specified columns

**extend** — creates a new column by computing a value

**summarize** — Aggregates groups of row

**render** — Renders results as a graphical output

### Reference

[Write queries for Azure Data Explorer](https://docs.microsoft.com/en-us/azure/data-explorer/write-queries)

```
StormEvents
| where EventType == 'Flood'
| sort by DamageProperty desc
| take 5
| project StartTime, EndTime, State, EventType

StormEvents
| where EventType == 'Flood'
| top 5
| project StartTime, EndTime, State, EventType

StormEvents | count
```

Note how `extend` creates a new column.

```
StormEvents
| where EventType == 'Flood'
| sort by DamageProperty desc
| top 5 by DamageProperty desc
| extend Duration = EndTime - StartTime
| project StartTime, EndTime, State, EventType
```

Render results in a graphical output.

```
StormEvents
| summarize event_count = count() by bin(StartTime, 1d)
| render timechart
```

## Metrics Explorer

**Metrics Explorer** is a sub-service of Azure Monitor that allows you to **plot charts, visualize correlating trends**, and **investigate spikes and dips** in **metrics values.**

Charting options

To visualize a metric you need to *define*:

**Scope**: You can select *resource(s) Eg. VM, StorageAccount

**Namespace**: a specific group of metric data within a resource

**Metric**: The actual value you are interested in visualizing

**Aggregation**: how you want group the values into the final result

### Reference

[Getting started with Azure Metrics Explorer](https://docs.microsoft.com/en-us/azure/azure-monitor/essentials/metrics-getting-started)

[Azure Monitor Metrics overview](https://docs.microsoft.com/en-us/azure/azure-monitor/essentials/data-platform-metrics)

# Azure Alerts

---

## Azure Alerts

**Alerts** notify you when issues are found with your infrastructure or application

They allow you to **identify** and **address** issues before the users of your system notice them.

Azure has 3 kinds of Alerts

1. Metric Alerts
2. Log Alerts
3. Activity Log Alerts

When an alert is triggered you can be notified and have it take action

The **Alert Rule** defines who should we monitor and when should we react

A resource such as an Azure VM is designated as the **Target Resource** and it omits a **signal**

The **Signal** is a data payload emitted from the resource that could be the following types:

- Metric
- Log
- Activity log
- Application Insights

The signal is evaluated against a **criteria or logical test** to determine if the alert has been triggered

eg. Percentage CPU > 70%

An **action group** contains actions to be that will be performed when alert is triggered

An **action** could be a: Automation runbook, Azure Function, ITSM, Logic App, Webhooks or Secure Webhooks

The current state of your alert **Monitor Condition** is set by the system **Alert state** is set by the user

### Reference

[Overview of alerts in Microsoft Azure](https://docs.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-overview)

## Azure Dashboards

**Dashboards** are a virtual workspaces to **quickly launch tasks for day-to-day operations and monitor resources**

Build custom dashboards based on projects, tasks, or user roles

### Reference

[Create a dashboard in the Azure portal](https://docs.microsoft.com/en-us/azure/azure-portal/azure-portal-dashboards#:%7E:text=Dashboards%20are%20a%20focused%20and,day%2Dto%2Dday%20operations)

## Azure Workbooks

**Workbooks** provide a flexible **canvas for data analysis** and the creation of rich visual reports within the Azure portal.

They allow you to tap into multiple data sources from across Azure and combine them into unified interactive experiences.

It tells a **story** about the performance and availability of your applications and services.

Workbooks are temporary workspaces to define a document-like format with visualization intertwined to help investigate and discuss performance.

**Perhaps a good idea if you want to show proof of when systems were down or you were blocked.**

### Reference

[Azure Monitor Workbooks](https://docs.microsoft.com/en-us/azure/azure-monitor/platform/workbooks-overview)

# Azure Monitor Cheatsheet

## Azure Monitor CheatSheet

Azure Monitor comprehensive solution for collecting, analyzing, and acting on telemetry from your cloud and on-premises environments

- Create Visual Dashboards
- Smart Alerts
- Automated Actions
- Log Monitoring

To obtain observability you need to use Metrics, Logs, and Traces.

- You have to use them together, using them in isolate does not gain you observability
    - Metrics: A number that is measured over a period of time
    - Logs A text file where each line contains event data about what happened at a certain time.
    - Traces: A history of requests that travels through multiple Apps/services so we can pinpoint performance or failure.

Azure Monitor collects two fundamental types of data from sources: Logs and Metrics

Azure Monitor Logs: collects and organizes log and performance data from monitored resources

- data logs are consolidated from different sources into workspaces
    - platform logs from Azure services,
    - log and performance data from virtual machines agents,
    - usage and performance data from applications can be consolidated
    - In a workspace, so they can be analyzed together using a sophisticated query language capable of analyzing millions of records.
- Work with log queries and their results interactively using Log Analytics

Azure Monitor Metrics collects numeric data from monitored resources into a time-series database.

- Metrics are numerical values collected at regular intervals and describe some aspect of a system at a particular time
- lightweight and capable of supporting near real-time scenarios, useful for alerting and fast detection of issues
- You can analyze them interactively with Metrics Explorer

Log Analytics is a tool in the Azure portal used to edit and run log queries with data in Azure Monitor Logs.

- Log Analytics uses a query language called KQL

Log Analytics workspace is a unique environment for Azure Monitor log data

- Each workspace has its own data repository and configuration, data sources and solutions are configured to store their data in a workspace

Azure Monitor Logs is based on Azure Data Explorer, and log queries are written using the same Kusto query language (KQL)

KQL can be used in: Log Analytics, Log alert rules, Workbooks, Azure Dashboards, Logic Apps, PowerShell, Azure Monitor Logs API

Kusto is based on relational database management systems and supports entities such as databases, tables, and columns.

- Some query operators include
    - calculated columns, searching and filtering on rows, group by-aggregates, join functions
- Kusto queries execute in the context of some Kusto database that is attached to a Kusto cluster.
- Kusto is generally composed of the following entities: Clusters, Databases, Tables, Columns, Functions
    - Clusters are entities that hold databases
    - Databases are named entities that hold tables and stored functions
    - Stored functions are named entities that allow reuse of Kusto queries or query parts.
    - Tables are named entities that hold data.
    - Columns are named entities that have a scalar data type.
    - External tables are entities that reference data stored outside Kusto database.

Metrics Explorer is a sub-service of Azure Monitor that allows you to plot charts, visualize correlating trends, and investigate spikes and dips in metrics values. To visualize a metric you need to define:

- Scope: You can select *resource(s)
- Namespace: a specific group of metric data within a resource
- Metric: The actual value you are interested in visualizing
- Aggregation: how you want to group the values into the final result

Alerts notify you when issues are found with your infrastructure or application

- They allow you to identify and address issues before the users of your system notice them.
- Azure has 3 kinds of Alerts
1. Metric Alerts
2. Log Alerts
3. Activity Log Alerts

Azure Dashboards are virtual workspaces to quickly launch tasks for day-to-day operations and monitor resources

Azure Workbooks provide a flexible canvas for data analysis and the creation of rich visual reports within the Azure portal.

- It tells a story about the performance and availability of your applications and services.

Application Insights is an Application Performance Management (APM) service It is a sub-service of Azure Monitor.

- automatically detect performance anomalies
- includes powerful analytics tools to help you diagnose issues and to understand what users do with your app
- designed to help you continuously improve performance and usability
- works for apps on a for .NET, Node.js, Java, and Python hosted on-premises, hybrid, or any public cloud.
- Integrates with your DevOps process
- can monitor and analyze telemetry from mobile apps by integrating with Visual Studio App Center

To use Application Insights you need to instrument your application.

- To instrument, you need to install the instrument package (SDK)
- Or enable Application Insights using the Application Insights Agents when supported
- Apps can be instrumented from anywhere
- When you set up Application Insights monitoring for your web app, you create an Application Insights resource in Microsoft Azure.
- You open this resource in the Azure portal in order to see and analyze the telemetry collected from your app.
- The resource is identified by an instrumentation key (ikey)