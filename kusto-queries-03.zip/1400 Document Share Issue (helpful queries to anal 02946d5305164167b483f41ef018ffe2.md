# 1400 Document Share Issue (helpful queries to analyze uploaded documents)

Created: September 13, 2022 2:44 PM

We had a user that uploaded a lot of documents yesterday - just under 1400 documents. I had a look at the documents as only under 1000 were shared and saw that the CurrentVersionNumber is set to NULL. That is approx. a third of all the documents uploaded and worrying. Please can you have a look at insights to see if you can spot why? 

- Context 91A0ECD1-53D5-45E8-D0C6-08DA8C3E96E1 (GHD ats Municipality of Kincardine)
- Group 587F5410-BAE9-4F59-3056-08D952A9CD6E.

When is the current version number set to null? 

Do any of these documents have operations across the  board?

- User is an ACL User
- First document created at `2022-09-12 20:32:51.9048133` and the last document was created at `2022-09-12 20:35:56.5179940`. 2 Minute interval between first and the last document being created.
- No. of documents created 1369

```sql
SELECT
    MIN(D.CreatedAt),
    MAX(D.CreatedAt)
FROM 
    Contexts C
    INNER JOIN UserGroups UG ON UG.Id = C.GroupId
    INNER JOIN Users U On U.UserGroupId = UG.Id
    INNER JOIN ContextDocument CD on CD.ContextId = C.Id
    INNER JOIN Documents D ON D.Id = CD.DocumentId
WHERE 
    U.Id = @UserId AND UG.Id = @UserGroupId
    AND D.CreatedAt BETWEEN '2022-09-11' AND '2022-09-14'
```

```sql
DECLARE @UserId VARCHAR(255) = '19a7b899-b44a-4a45-88cf-08d952a9cd6d'
DECLARE @UserGroupId UNIQUEIDENTIFIER = (SELECT UserGroupId FROM Users WHERE Id = @UserId)
DECLARE @ContextId UNIQUEIDENTIFIER = '91A0ECD1-53D5-45E8-D0C6-08DA8C3E96E1'

SELECT DISTINCT
    D.id
FROM 
    Contexts C
    INNER JOIN UserGroups UG ON UG.Id = C.GroupId
    INNER JOIN Users U ON U.UserGroupId = UG.Id
    INNER JOIN ContextDocument CD on CD.ContextId = C.Id
    INNER JOIN Documents D ON D.Id = CD.DocumentId
WHERE 
    U.Id = @UserId AND UG.Id = @UserGroupId AND
    C.Id = '91A0ECD1-53D5-45E8-D0C6-08DA8C3E96E1'
    AND D.CreatedAt BETWEEN '2022-09-11' AND '2022-09-14'
```

```sql
SELECT
    d.*,
    dje.ActionedAt,
    dv.*
from 
    documents d
    inner join documentversions dv on dv.documentId = d.Id
    inner join DocumentJournalEntries dje ON DJE.DocumentId = D.Id
WHERE
    DJE.[Action] = 'Created' AND d.ContextId = '91A0ECD1-53D5-45E8-D0C6-08DA8C3E96E1'
    AND D.currentversionNumber IS NOT NULL
```

---

```
SELECT
    d.*,
    dje.ActionedAt
from 
    documents d
    inner join DocumentJournalEntries dje ON DJE.DocumentId = D.Id
WHERE
    DJE.[Action] = 'Created' AND d.ContextId = '91A0ECD1-53D5-45E8-D0C6-08DA8C3E96E1'
    AND D.currentversionNumber IS NOT NULL
```

### Yesterday’s

- The user never uploaded all the documents that he created because it looks legit. Looks like incremental log snapshots over a day.
- Looks like the user tried to upload a shit load of documents in one go.
- Looks like a bunch of frames of  a video or something.
- Large amount of them just failed. Either browser crashed or he just gave up.
- Maybe he closed his browser by mistake.
- 934 files were uploaded.
- Usage looks legitimate.
- Application Insights is best effort, we’re not getting all the logs.

```
let fromDate = datetime("2022-09-09");
let toDate =  datetime("2022-09-14");

requests
| where timestamp >= fromDate and timestamp <= toDate
| where customDimensions.["xd-user-id"] == "19a7b899-b44a-4a45-88cf-08d952a9cd6d"
| where customDimensions.["xd-api-key"] == "49EF5C2A6B674C5FBACAD9D9575117A7"
| where operation_Name startswith "POST"
| order by timestamp desc
```

---

## User Details

```sql
DECLARE @UserId VARCHAR(255) = '19a7b899-b44a-4a45-88cf-08d952a9cd6d'
DECLARE @UserGroupId UNIQUEIDENTIFIER = (SELECT UserGroupId FROM Users WHERE Id = @UserId)

SELECT 
    'User Details',
    U.Id AS UserId,
    U.Email as UserEmail,
    U.Role as Role,
    UG.Id as UserGroupId,
    UG.Name AS GroupName
FROM 
    Users U
    INNER JOIN UserGroups UG ON UG.Id = U.UserGroupId
WHERE 
    U.Id = @UserId

SELECT 
    'User Activation Details',
    U.Email as UserEmail,
    U.Deleted AS UserDeleted,
    U.CreatedAt AS CreatedAt,
    U.ActivatedOn AS ActivatedOn
FROM 
    Users U
WHERE 
    U.Id = @UserId

SELECT 
    'Group Details',
    UG.Id as UserGroupId,
    UG.Name AS GroupName,
    UG.SubscriptionType AS Subscription,
    UG.PartnerCode,
    UG.Deleted AS GroupDeleted,
    UG.CreatedAt
FROM 
    Users U
    INNER JOIN UserGroups UG ON UG.Id = U.UserGroupId
WHERE 
    U.Id = @UserId

-- User ID 19a7b899-b44a-4a45-88cf-08d952a9cd6d	
-- lmajek@sorbaralaw.com	Administrator	
-- UserGroup: 587f5410-bae9-4f59-3056-08d952a9cd6e	(Sorbara, Schumacher, McCann LLP)
-- CreatedAt: 2021-08-13 17:03:09.0198205
```

### Kusto Query to check for document created by a user

This value returns only 329 documents

```
let fromDate = datetime("2022-09-10");
let toDate =  datetime("2022-09-14");

requests
| where timestamp > fromDate and timestamp < toDate
| where customDimensions.["xd-user-id"] == "19a7b899-b44a-4a45-88cf-08d952a9cd6d"
| where name == "POST ContextDocuments/CreateDocument [contextId]"
| order by timestamp desc
```

### Get a list of distinct calls for a user for today

```
let fromDate = datetime("2022-09-11");
let toDate =  datetime("2022-09-14");

requests
| where timestamp > fromDate and timestamp < toDate
| where customDimensions.["xd-user-id"] == "19a7b899-b44a-4a45-88cf-08d952a9cd6d"
| order by timestamp desc
| distinct name
```

### Total number of distinct calls for this user

```
let fromDate = datetime("2022-09-11");
let toDate =  datetime("2022-09-14");

requests
| where timestamp > fromDate and timestamp < toDate
| where customDimensions.["xd-user-id"] == "19a7b899-b44a-4a45-88cf-08d952a9cd6d"
| order by timestamp desc
| project name
| summarize call_count=count() by name
```

### No. of Docs  Created (Another Way through Journal)

```
SELECT
    d.*,
    dje.ActionedAt
from 
    documents d
    inner join DocumentJournalEntries dje ON DJE.DocumentId = D.Id
WHERE
    DJE.[Action] = 'Created' AND d.ContextId = '91A0ECD1-53D5-45E8-D0C6-08DA8C3E96E1'
```

```
let fromDate = datetime("2022-09-09");
let toDate =  datetime("2022-09-14");

requests
| where timestamp >= fromDate and timestamp <= toDate
| search "a6bde852-d973-4811-06d0-08da8c3fc562"
| order by timestamp desc
```

```
let fromDate = datetime("2022-09-09");
let toDate =  datetime("2022-09-14");

requests
| where timestamp >= fromDate and timestamp <= toDate
| where name == "POST ContextDocuments/CreateDocument [contextId]"
| where customDimensions.["xd-user-id"] == "19a7b899-b44a-4a45-88cf-08d952a9cd6d"
| search "91a0ecd1-53d5-45e8-d0c6-08da8c3e96e1"
| order by timestamp desc
```

If the `xd-api-key` is `49EF5C2A6B674C5FBACAD9D9575117A7` then the log entry is from `xchangedocs` and `815...` would come from ACL.

```
let fromDate = datetime("2022-09-09");
let toDate =  datetime("2022-09-14");

requests
| where timestamp >= fromDate and timestamp <= toDate
| where name == "POST ContextDocuments/CreateDocument [contextId]"
| where customDimensions.["xd-user-id"] == "19a7b899-b44a-4a45-88cf-08d952a9cd6d"
| where customDimensions.["xd-api-key"] == "49EF5C2A6B674C5FBACAD9D9575117A7"
| search "91a0ecd1-53d5-45e8-d0c6-08da8c3e96e1" // Context ID
| order by timestamp desc
```

### Old Documentation

[https://github.com/korbicom/xchangedocs-product/issues/213](https://github.com/korbicom/xchangedocs-product/issues/213)

[https://github.com/korbicom/xchangedocs-webclient/issues/531](https://github.com/korbicom/xchangedocs-webclient/issues/531)

[https://github.com/korbicom/xchangedocs-product/issues/541](https://github.com/korbicom/xchangedocs-product/issues/541)

Prof’s Upload Spec: [https://github.com/korbicom/xchangedocs-server/wiki/Resumeable-Uploads](https://github.com/korbicom/xchangedocs-server/wiki/Resumeable-Uploads)