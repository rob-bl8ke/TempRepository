# Kusto support queries

Category: Kusto
Created: July 6, 2022 3:18 PM
Status: Open
Updated: September 2, 2022 6:35 AM

# Specific

### Notifier

You should run this on ****`notifier8xdprod4can` [and you can access this here](https://portal.azure.com/#@azurekorbicom.onmicrosoft.com/resource/subscriptions/a563e6c3-b908-445b-8894-ee0291a96aa7/resourceGroups/xchangedocs-production-canada/providers/microsoft.insights/components/notifier8xdprod4can/logs).**

```
let fromDate = ago(2d);
let toDate = now() + 1d;
// let fromDate = startofday(datetime("2021-01-01"))
// let toDate = endofday(datetime("2021-01-21"))

let minResponseCode = 400;
let maxResponseCode = 600;

customMetrics
| where name contains "Notifications"
| where operation_Name == "ReminderFunction"
| where timestamp > fromDate and timestamp < toDate
| order by timestamp desc
```

Use this call to find out which reminders were requested from the API Server from the Notifier. This call needs to be run on ****`insights-xdprod4can` [which is located here](https://portal.azure.com/#@azurekorbicom.onmicrosoft.com/resource/subscriptions/a563e6c3-b908-445b-8894-ee0291a96aa7/resourceGroups/xchangedocs-production-canada/providers/microsoft.insights/components/insights-xdprod4can/logs).** 

```
let fromDate = ago(2d);
let toDate = now() + 1d;
// let fromDate = startofday(datetime("2021-01-01"))
// let toDate = endofday(datetime("2021-01-21"))

let minResponseCode = 200;
let maxResponseCode = 300;

requests
| where timestamp > fromDate and timestamp < toDate
| where toint(resultCode) >= minResponseCode and toint(resultCode) < maxResponseCode
| where url contains "reminders/standard-activations" or url contains "reminders/standard-activations" or url contains "reminders/migrations"
| order by timestamp desc
```

# General

Look for a call with a URL that contains the following text.

```
let fromDate = ago(2d);
let toDate = now() + 1d;

let minResponseCode = 200;
let maxResponseCode = 205;

requests
| where timestamp > fromDate and timestamp < toDate
| where toint(resultCode) >= minResponseCode and toint(resultCode) < maxResponseCode
| where url contains "reminders"
| order by timestamp desc
```

Look for authentication calls.

```
let userId = "";

let fromDate = startofday(datetime("2021-01-01"));
// let toDate = endofday(datetime("2021-01-21"));
// let fromDate = ago(10d);
let toDate = now() + 1d;

requests
| where timestamp > fromDate and timestamp < toDate
| where operation_Name contains "GetAuthenticatedUser"
| order by timestamp desc
```

Be more specific about the result code.

```
let userId = "";

let fromDate = ago(10d);
let toDate = now() + 1d;
// let fromDate = startofday(datetime("2021-01-01"))
// let toDate = endofday(datetime("2021-01-21"))

let minResponseCode = 200;
let maxResponseCode = 600;

requests
| extend response = case(
        resultCode == 200, "200 - OK",
        resultCode == 201, "201 - Created",
        resultCode == 202, "202 - Accepted",
        resultCode == 203, "203 - Non-Authoritative Information",
        resultCode == 204, "204 - No Content",
        resultCode == 205, "205 - Reset Content",
        resultCode == 206, "206 - Partial Content",
        resultCode == 301, "301 - Moved permanently",
        resultCode == 302, "302 - Found",
        resultCode == 303, "303 - See Other",
        resultCode == 304, "304 - Not Modified",
        resultCode == 305, "305 - Use Proxy",
        resultCode == 306, "306 - (Unused)",
        resultCode == 307, "307 - Temporary Redirect",
        resultCode == 400, "400 - Bad Request",
        resultCode == 401, "401 - Unauthorized",
        resultCode == 403, "403 - Forbidden",
        resultCode == 404, "404 - Resource not found",
        resultCode == 405, "405 - Method Not Allowed",
        resultCode == 406, "406 - Not Acceptable",
        resultCode == 407, "407 - Proxy Authentication Required",
        resultCode == 408, "408 - Request Timeout",
        resultCode == 409, "409 - Conflict",
        resultCode == 410, "410 - Gone",
        resultCode == 411, "411 - Length Required",
        resultCode == 412, "412 - Precondition Failed",
        resultCode == 413, "413 - Request Entity Too Large",
        resultCode == 414, "414 - Request URI Too Long",
        resultCode == 415, "415 - Unsupported Media Type",
        resultCode == 416, "416 - Requested Range not satisfiable",
        resultCode == 417, "417 - Expectation Failed",
        resultCode == 500, "500 - Internal Server Error",
        resultCode == 501, "501 - Not Implemented",
        resultCode == 502, "502 - Bad Gateway",
        resultCode == 503, "503 - Service Unavailable",
        resultCode == 504, "504 - Gateway Timeout",
        resultCode == 505, "505 - HTTP Version Not Supported",
        "--UNKNOWN--"
    )
| where timestamp > fromDate and timestamp < toDate
| where customDimensions.["xd-user-id"] == userId
| where toint(resultCode) >= minResponseCode and toint(resultCode) < maxResponseCode
| project timestamp, customDimensions.["xd-user-id"], operation_Id, operation_Name, response, duration
| order by timestamp desc
```

You're looking for customDimensions1.Error (on the dependencies table).

```
// 

let userId = "";

// let fromDate = startofday(datetime("2021-02-25 10:48:35.000 PM"));
// let toDate = endofday(datetime("2021-02-25 10:58:35.000 PM"));

// Last time tried was Thursday 10:42 PM...
// let fromDate = ago(5d);
// let toDate = now() + 1d;

let minResponseCode = 400;
let maxResponseCode = 499;

requests
| join (dependencies) on operation_Id
| where timestamp > fromDate and timestamp < toDate
| where customDimensions1.Error != ""
| where customDimensions.["xd-user-id"] == userId
| where toint(resultCode) >= minResponseCode and toint(resultCode) < maxResponseCode
| order by timestamp desc
```

### Kusto Language Reference

[Learn Kusto Query Language - String Operators](https://www.eshlomo.us/learn-kusto-query-language-string-operators/)